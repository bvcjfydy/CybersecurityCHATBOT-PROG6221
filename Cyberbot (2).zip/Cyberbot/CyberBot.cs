﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Media;

namespace Cyberbot
{
    public class CyberBot
    {
        // Memory and Recall: Storing user details and preferences[cite: 6]
        public string UserName { get; set; }
        public string FavoriteTopic { get; set; }
        public string LastDiscussedTopic { get; set; }
        public string LastSentiment { get; set; }
        public string AudioFilePath { get; set; } = "greeting.wav";

        // Collections for Randomized Responses & Dictionaries for Optimization[cite: 4, 8]
        private readonly Random _random = new Random();

        private readonly Dictionary<string, List<string>> _topicResponses = new Dictionary<string, List<string>>
        {
            {
                "password", new List<string>
                {
                    "Password Safety: Always use strong passwords with at least 12 characters mixing uppercase, lowercase, numbers, and symbols[cite: 3]. Never reuse passwords across accounts!",
                    "Password Tips: Consider using a reputable password manager to generate and securely store unique credentials for every site you visit.",
                    "Credential Security: Avoid using personal details like birthdays or pet names in your passwords, as these are easily guessed by cybercriminals[cite: 3]."
                }
            },
            {
                "safe browsing", new List<string>
                {
                    "Safe browsing: Always check for https:// in the URL bar and avoid downloading attachnents from unverified sources or public Wi-Fi networks.",
                    "Unsafe browsing: Hackers can trick  you by setting up fake websites with misspelled web addresses to steal your passwords when you panic and login.",
                    "Typosquatting Prevention: Bookmark official pages and if you did not bookmark the pages, search for the service name on Google.",
                }
            },
            {
                "privacy", new List<string>
                {
                    "Privacy Protection: Regularly review your social media and account privacy settings to limit what personal information is publicly visible[cite: 6].",
                    "Data Privacy: Be mindful of the permissions you grant to mobile apps and browser extensions. Only share what is strictly necessary.",
                    "Digital Footprint: Protecting your privacy means minimizing unnecessary data exposure online and understanding how companies collect your information."
                }
            },
            {
                "phishing", new List<string>
                {
                    "Phishing Alert: Inspect sender email addresses closely for subtle misspellings. Never click unexpected links in unsolicited emails.",
                    "Phishing Defense: Legitimate institutions will never ask for your PIN, OTP, or full password via email or text message.",
                    "Email Security: Hover over links before clicking to preview the actual destination URL and avoid malicious trap sites."
                }
            }
        };

        // Task 1: Voice Greeting integration for GUI[cite: 2]
        public void PlayVoiceGreeting()
        {
            try
            {
                if (File.Exists(AudioFilePath))
                {
                    using (SoundPlayer player = new SoundPlayer(AudioFilePath))
                    {
                        player.Play();
                    }
                }
            }
            catch (Exception)
            {
                // Fail silently or handle gracefully for GUI compatibility
            }
        }

        // Task 1 & 2: ASCII Logo represented as a clean string for GUI TextBoxes/Labels[cite: 2]
        public string GetAsciiLogo()
        {
            return "============================================================\n" +
                   "      ______   __         ____  ____  ____  ______    \n" +
                   "     / ____/_ _/ /_  ___  ____/ /  |/  / |/ /  |/ / __ \\   \n" +
                   "    / /   / / / / __ \\/ _ \\/ __  / /|_/ /|_/ /|_/ / /_/ /   \n" +
                   "   / /___/ /_/ / /_/ /  __/ /_/ / /  / /  / /  / /____/    \n" +
                   "   \\____/\\__,_/_.___/\\___/\\__,_/_/  /_/  /_/  /_/         \n" +
                   "                                                          \n" +
                   "            CYBERSECURITY AWARENESS ASSISTANT             \n" +
                   "============================================================";
        }

        // Main Query Processing Engine incorporating Sentiment Detection, Memory, and Flow[cite: 3, 5, 6, 7, 8]
        public string ProcessUserQuery(string rawInput)
        {
            if (string.IsNullOrWhiteSpace(rawInput))
            {
                return "Bot: I didn't catch that. Please type a valid question or topic[cite: 8].";
            }

            string query = rawInput.Trim().ToLower();

            // 1. Sentiment Detection[cite: 7]
            DetectSentiment(query);

            // 2. Memory & Recall: Storing favorite topics dynamically[cite: 6]
            if (query.Contains("interested in") || query.Contains("love") || query.Contains("favorite"))
            {
                if (query.Contains("password")) FavoriteTopic = "password security";
                else if (query.Contains("safe browsing")) FavoriteTopic = "Safe browsing";
                else if (query.Contains("privacy")) FavoriteTopic = "online privacy";
                else if (query.Contains("phishing")) FavoriteTopic = "phishing awareness";

                if (!string.IsNullOrEmpty(FavoriteTopic))
                {
                    return $"Bot: Great! I'll remember that you're interested in {FavoriteTopic}. It's a crucial part of staying safe online[cite: 6].";
                }
            }

            // 3. Conversation Flow: Handling follow-up requests ("tell me more", "another tip")[cite: 5]
            if ((query.Contains("more") || query.Contains("another tip") || query.Contains("explain")) && !string.IsNullOrEmpty(LastDiscussedTopic))
            {
                return GetRandomResponse(LastDiscussedTopic, isFollowUp: true);
            }

            // 4. Keyword Recognition & Randomized Responses[cite: 3, 4]
            if (query.Contains("password"))
            {
                LastDiscussedTopic = "password";
                return GetSentimentPrefix() + GetRandomResponse("password");
            }
            else if (query.Contains("safe browsing") || query.Contains("fraud"))
            {
                LastDiscussedTopic = "safe browsing";
                return GetSentimentPrefix() + GetRandomResponse("safe browsing");
            }
            else if (query.Contains("privacy"))
            {
                LastDiscussedTopic = "privacy";
                return GetSentimentPrefix() + GetRandomResponse("privacy");
            }
            else if (query.Contains("phishing") || query.Contains("email"))
            {
                LastDiscussedTopic = "phishing";
                return GetSentimentPrefix() + GetRandomResponse("phishing");
            }
            else if (query.Contains("hello") || query.Contains("hi"))
            {
                string memoryGreeting = !string.IsNullOrEmpty(FavoriteTopic)
                    ? $" It's great to chat with you again, {UserName}. How is your journey learning about {FavoriteTopic} going[cite: 6]?"
                    : $" Hello, {UserName}! How can I help secure your digital life today?";
                return "Bot:" + memoryGreeting;
            }
            else if (query.Contains("help") || query.Contains("topics"))
            {
                return "Bot: You can ask me about 'password safety', 'safe browsing', 'privacy', or 'phishing'. You can also type 'tell me more' for follow-up tips[cite: 3, 5]!";
            }

            // 5. Error Handling / Default Response for Unrecognized Inputs[cite: 8]
            return $"Bot: I'm not entirely sure I understand, {UserName}. Can you try rephrasing or type 'help' for available topics[cite: 8]?";
        }

        private void DetectSentiment(string query)
        {
            if (query.Contains("worried") || query.Contains("scared") || query.Contains("anxious") || query.Contains("nervous"))
            {
                LastSentiment = "worried";
            }
            else if (query.Contains("curious") || query.Contains("wondering") || query.Contains("how does"))
            {
                LastSentiment = "curious";
            }
            else if (query.Contains("frustrated") || query.Contains("confused") || query.Contains("stuck"))
            {
                LastSentiment = "frustrated";
            }
            else
            {
                LastSentiment = "neutral";
            }
        }

        private string GetSentimentPrefix()
        {
            // Sentiment Detection Adjustment (providing empathetic support)[cite: 7]
            if (LastSentiment == "worried")
            {
                return "Bot (Empathetic Note): It's completely understandable to feel that way. Scammers can be very convincing, but you're taking the right steps to stay safe[cite: 7].\n\n";
            }
            else if (LastSentiment == "frustrated")
            {
                return "Bot (Supportive Note): Cybersecurity can certainly feel overwhelming at times, but we will take it one step at a time[cite: 7].\n\n";
            }
            return "Bot: ";
        }

        private string GetRandomResponse(string topic, bool isFollowUp = false)
        {
            if (_topicResponses.ContainsKey(topic))
            {
                var list = _topicResponses[topic];
                int index = _random.Next(list.Count);
                string response = list[index];

                if (isFollowUp)
                {
                    return $"Bot [Follow-up Tip]: Here is another helpful pointer regarding {topic}: {response}[cite: 5]";
                }
                return response;
            }
            return "Bot: Stay vigilant and keep your software updated.";
        }
    }
}