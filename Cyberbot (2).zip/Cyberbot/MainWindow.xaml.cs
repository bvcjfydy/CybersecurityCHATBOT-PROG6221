﻿using System.Windows;
using System.Windows.Input;

namespace Cyberbot
{
    public partial class MainWindow : Window
    {
        private CyberBot _bot;

        public MainWindow()
        {
            InitializeComponent();
            _bot = new CyberBot();

            // Display ASCII logo in the WPF UI
            TxtLogo.Text = _bot.GetAsciiLogo();

            // Play voice greeting if available
            _bot.PlayVoiceGreeting();

            // Initial bot prompt
            TxtChatHistory.AppendText("Bot: Welcome to the Cybersecurity Awareness Portal! Please enter your name in the chat or type a message to begin.\n\n");
        }

        private void BtnSend_Click(object sender, RoutedEventArgs e)
        {
            ProcessInput();
        }

        private void TxtUserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ProcessInput();
            }
        }

        private void ProcessInput()
        {
            string input = TxtUserInput.Text.Trim();
            if (string.IsNullOrEmpty(input)) return;

            // Display user message
            TxtChatHistory.AppendText($"You: {input}\n");

            // Handle name capture if not set yet
            if (string.IsNullOrEmpty(_bot.UserName))
            {
                _bot.UserName = input;
                TxtChatHistory.AppendText($"Bot: Hello, {_bot.UserName}! I am here to help you navigate online safety. Type 'help' to view topics.\n\n");
            }
            else
            {
                // Process through the backend logic
                string response = _bot.ProcessUserQuery(input);
                TxtChatHistory.AppendText($"{response}\n\n");
            }

            // Clear input box and scroll to bottom
            TxtUserInput.Clear();
            TxtChatHistory.ScrollToEnd();
        }

        private void TxtChatHistory_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {

        }
    }
}